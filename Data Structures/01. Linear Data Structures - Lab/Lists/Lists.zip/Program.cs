﻿public class Program
{
    public static void Main(string[] args)
    {
        ArrayList<int> array = new ArrayList<int>();

        array.Add(2);
        array.Add(2);
        array.Add(2);

    }
}
